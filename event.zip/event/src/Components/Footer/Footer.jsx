import "./Footer.css";
const Footer = () => {
  return (
    <>
      <footer>
        <h6>&copy; Easy Coding Tutorial</h6>
      </footer>
    </>
  );
};
export default Footer;
