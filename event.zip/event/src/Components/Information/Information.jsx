import "./Information.css";
const Information = () => {
  return (
    <>
      <div className="Information container">
        <div className="row justify-content-center">
          <div className="col-sm-8">
            <h6>Premier Developers' Conference</h6>
            <p>
              The Premier Developers' Conference is the ultimate gathering for
              developers seeking to expand their knowledge, skills, and
              networks. <br />
              <br />
              This exclusive event brings together industry-leading experts,
              innovative minds, and technology enthusiasts to explore the latest
              trends, advancements, and best practices in software development.{" "}
              <br />
              <br /> From insightful keynotes to interactive workshops and
              networking sessions, this conference offers an immersive
              experience that empowers developers to thrive in the fast-paced
              world of coding. <br />
              <br /> Whether you're a seasoned professional or just starting
              your coding journey, join us at the Premier Developers' Conference
              and unlock new possibilities for growth, collaboration, and
              success.
            </p>
          </div>
        </div>
      </div>
    </>
  );
};
export default Information;
