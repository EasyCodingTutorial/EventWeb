import React from "react";
import "./Home.css";
const Home = () => {
  return (
    <>
      <div className="Home">
        <div className="container">
          <div className="row">
            <div className="col-sm-7">
              <h6>Time To Change</h6>
              <h5>Limitless Possibilities!</h5>
              <p>
                "Limitless Possibilities" captures the essence of our events
                where boundaries are shattered, and the realm of possibilities
                knows no bounds. <br />
                <br /> Prepare to embark on a transformative journey where
                inspiration meets innovation, and where you'll discover the
                power within you to achieve greatness. Unleash your potential,
                explore new horizons, and embrace the endless opportunities that
                await you at our events. Get ready to be inspired, motivated,
                and empowered to reach heights you never thought possible. Join
                us and step into a world of limitless possibilities.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
