import "./Upcoming.css";
import Upcoming1 from "../../Images/upcoming1.jpg";
import Upcoming2 from "../../Images/upcoming2.jpg";
import Upcoming3 from "../../Images/upcoming3.jpg";
import Upcoming4 from "../../Images/upcoming4.jpg";
import Upcoming5 from "../../Images/upcoming5.jpg";
import Upcoming6 from "../../Images/upcoming6.jpg";
const UpcomingEvent = () => {
  return (
    <>
      <div className="container Upcoming">
        <div className="content">
          <h6>
            Upcoming <span>Events</span>
          </h6>
          <p>
            Join us for a memorable experience filled with entertainment,
            knowledge, and connections.
          </p>
        </div>

        <div className="row">
          <div className="col-sm-4">
            <div className="box">
              <img src={Upcoming1} className="img-fluid" alt="" />
            </div>
            <div className="boxContent">
              <h6>Tech Innovators Summit</h6>
              <p>
                Join us from September 15-17, 2023, at the Tech Innovators
                Summit, where visionary leaders, entrepreneurs, and
                technologists gather to explore the latest breakthroughs and
                emerging technologies shaping the future. From AI and blockchain
                to robotics and IoT, this event offers a platform to gain
                insights, share knowledge, and foster collaborations that will
                drive innovation forward.
              </p>
            </div>
          </div>

          <div className="col-sm-4">
            <div className="box">
              <img src={Upcoming2} className="img-fluid" alt="" />
            </div>
            <div className="boxContent">
              <h6>Digital Marketing Mastery Conference</h6>
              <p>
                Elevate your digital marketing game on October 8-9, 2023, at the
                Digital Marketing Mastery Conference. This event brings together
                marketing professionals, industry experts, and digital
                strategists to delve into the ever-evolving world of digital
                marketing. Discover the latest tactics, trends, and strategies
                to maximize your online presence, engage your audience, and
                drive measurable results.
              </p>
            </div>
          </div>

          <div className="col-sm-4">
            <div className="box">
              <img src={Upcoming3} className="img-fluid" alt="" />
            </div>
            <div className="boxContent">
              <h6>Cybersecurity Summit 2023</h6>
              <p>
                Protect your digital assets and stay ahead of cyber threats from
                November 5-7, 2023, at the Cybersecurity Summit 2023. This event
                gathers cybersecurity experts, thought leaders, and
                professionals to discuss the evolving landscape of
                cybersecurity, share best practices, and explore cutting-edge
                solutions. Gain valuable insights into threat intelligence, data
                protection, and risk mitigation strategies to safeguard your
                organization.
              </p>
            </div>
          </div>

          <div className="col-sm-4">
            <div className="box">
              <img src={Upcoming4} className="img-fluid" alt="" />
            </div>
            <div className="boxContent">
              <h6>Future of E-commerce Expo</h6>
              <p>
                Discover the future of e-commerce from December 12-14, 2023, at
                the Future of E-commerce Expo. This event brings together
                industry leaders, e-commerce experts, and technology providers
                to showcase the latest trends, innovations, and strategies
                revolution
              </p>
            </div>
          </div>

          <div className="col-sm-4">
            <div className="box">
              <img src={Upcoming5} className="img-fluid" alt="" />
            </div>
            <div className="boxContent">
              <h6>Data Science Symposium</h6>
              <p>
                Immerse yourself in the world of data science from January
                18-20, 2024, at the Data Science Symposium. Join data
                scientists, researchers, and analysts as they explore the
                forefront of data-driven insights, machine learning, and
                predictive modeling. Learn from industry pioneers, participate
                in hands-on workshops, and gain a deeper understanding of how
                data science is transforming industries.
              </p>
            </div>
          </div>

          <div className="col-sm-4">
            <div className="box">
              <img src={Upcoming6} className="img-fluid" alt="" />
            </div>
            <div className="boxContent">
              <h6>Agile Leadership Summit</h6>
              <p>
                Embrace agile methodologies and develop your leadership skills
                from February 22-24, 2024, at the Agile Leadership Summit. This
                event brings together agile coaches, scrum masters, and
                organizational leaders to share experiences, best practices, and
                strategies for effective agile implementation. Discover how to
                foster collaboration, adapt to change, and drive innovation in
                your organization through agile leadership principles and
                practices.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default UpcomingEvent;
