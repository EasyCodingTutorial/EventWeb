import React from "react";
import "./navbar.css";

const Navbar = () => {
  return (
    <>
      <div className="NavbarM">
        <a href="#" className="navbar-brand">
          Easy
        </a>
        <div>
          <h6>Give us Chance.</h6>
        </div>
      </div>

      <nav className="navbar navbar-expand">
        <div>
          <ul className="navbar-nav">
            <li className="nav-item">
              <a href="#" className="nav-link active">
                Home
              </a>
            </li>
            <li className="nav-item">
              <a href="#" className="nav-link">
                About
              </a>
            </li>
            <li className="nav-item">
              <a href="#" className="nav-link">
                Events
              </a>
            </li>
            <li className="nav-item">
              <a href="#" className="nav-link">
                Blog
              </a>
            </li>
            <li className="nav-item">
              <a href="#" className="nav-link">
                Contact
              </a>
            </li>
          </ul>
        </div>
      </nav>
    </>
  );
};

export default Navbar;
